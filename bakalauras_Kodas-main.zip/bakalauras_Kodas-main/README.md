# bakalauras_prif
bachelors work code. Android app that uses TF Lite model to control physical electronics with voice commands.
Integrated AI model uses CNN to clasify vocal input and sends command via bluetooth to connected electonical device
